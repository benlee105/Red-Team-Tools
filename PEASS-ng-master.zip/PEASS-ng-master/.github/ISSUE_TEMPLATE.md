If you are going to suggest something, please remove the following template. 
If your issue is related with WinPEAS.ps1 please mention https://github.com/RandolphConley

#### Issue description


#### Steps to reproduce the issue

1.  
2. 
3.

#### Which parameters did you use for executing the script and how did you execute it?


#### If winpeas, did you use a clean or obfuscated winpeas, and for which architecture?


#### Is there any AV / Threat protection in the system?


#### Please, indicate the OS, the OS version, and the kernel version (build number in case of Windows)


#### Please, indicate the check that is failing and add a screenshot showing the problem


#### How did you expect it to work?


#### Additional details / screenshot

