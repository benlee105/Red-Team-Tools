Invoke-Mimikatz is in Exfiltration folder
PowerUp is in Privesc folder
PowerView is in Recon folder