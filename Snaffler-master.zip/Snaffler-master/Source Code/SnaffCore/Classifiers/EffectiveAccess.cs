﻿

namespace SnaffCore.Classifiers.EffectiveAccess
{
    public class RwStatus
    {
        public bool CanRead { get; set; }
        public bool CanWrite { get; set; }
        public bool CanModify { get; set; }
    }

}
